# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer']

package_data = \
{'': ['*'], 'page_analyzer': ['templates/*']}

install_requires = \
['flake8>=6.0.0,<7.0.0',
 'flask>=2.2.3,<3.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'jinja2>=3.1.2,<4.0.0',
 'psycopg2-binary>=2.9.6,<3.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'railway>=0.0.4,<0.0.5']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/unt1tledd/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/unt1tledd/python-project-83/actions)',
    'author': 'Софья Григорович',
    'author_email': 'sonyashkin@icloud.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
